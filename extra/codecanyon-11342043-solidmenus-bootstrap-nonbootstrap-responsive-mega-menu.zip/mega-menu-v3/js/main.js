$(document).ready(function() { //if the DOM is ready

	var solidMenus = {

		default_menu: 'mega-menu-1.html', /**/
		default_animation: 'animation-hingeTop',
		swivel_animation: 'animation-hingeTop', //for mega-menu-6 only
		window_width: this.reportWindowWidth,
		nav_width: this.reportNavWidth,
		timer: '',
		scroll_fix_value: 25,
		init: function() {

			this.cacheDom();
			this.bindEvents();
			this.loadDefaultSettings();
			
		},
		cacheDom: function() {

			this.$window = $(window);
			this.$document = $(document);
			this.$body = $('body');
			this.$navigation = $('#navigation');
			this.$menu = $('#menu');
			this.$home_menu_li = this.$body.find('.home-menu li');
			this.$main_nav_li = this.$body.find('.main-nav > li');
			this.$div_animated = this.$body.find('div.animated');
			this.$full_width = $('.solid-menus .full-width, .solid-menus .gallery, .solid-menus .sub-menu-1.home, .solid-menus .tabs')
			this.$trigger_click_li = this.$body.find('.trigger-click > li');
			this.$trigger_hover_li = this.$body.find('.trigger-hover > li');
			this.$swivel_list = this.$body.find('.swivel-lists > li')
			this.$nav_fixed = this.$body.find('.navigation-fixed-top');
			this.$trigger_ft = this.$body.find('.trigger-fixed-top');

			/* settings section */

			this.$mega_menu_changer = $('#mega-menu-changer');
			this.$menu_changer = $('#select-mega-menu');
			this.$version_changer = $('#select-version');
			this.$responsiveness_changer = $('#select-responsiveness');
			this.$trigger_changer = $('#select-trigger');
			this.$theme_changer = $('#theme-changer');
			this.$trigger_ft = $('#select-trigger-fixed-top');
			this.$main_nav = this.$body.find('.main-nav');
			this.$animation_changer = $('#select-animation');
			this.$anim_and_trig = $('#select-animation, #select-trigger');

		},
		bindEvents: function() {

			this.$body.on('click', '.main-nav.trigger-click > li > a', this.triggerMenu);
			this.$body.on('mouseover', '.main-nav.trigger-hover > li > a', this.triggerMenu);
			this.$window.on('resize', this.calculateNavWidth);
			this.$body.on('mouseover', '.home-menu li', this.homeMenuHover);
			this.$document.on('click', 'html', this.triggerClickOutsideNav);
			this.$body.on('click', '.tab-menu .tab-marker li', this.openTab);
			this.$body.on('change', '#book-category', this.bookCategory);
			this.$body.on('click', '#menu', this.firstMenuOnly);
			this.$window.on('scroll', this.fixedTop.bind(this));
			this.$body.on('click', '.main-nav.main-nav-swivel.trigger-click > li', this.startSwivelClick);
			this.$body.on('touchstart', '#menu', function(){});

			/* settings section */

			this.$version_changer.on('change', this.changeVersion.bind(this));
			this.$menu_changer.on('change', this.changeMenu.bind(this));
			this.$responsiveness_changer.on('change', this.changeResponsiveness.bind(this));
			this.$trigger_changer.on('change', this.changeTrigger.bind(this));
			this.$theme_changer.on('click', 'li', this.changeTheme);
			this.$animation_changer.on('change', this.changeAnimation.bind(this));
			this.$trigger_ft.on('change', this.changeFt.bind(this));

		},
		loadMenu: function() {

			this.$navigation.load('ajax/' + this.default_menu, function() {

				solidMenus.loadDefaultSettings();

			});

		},
		loadDefaultSettings: function() {

			this.cacheDom();
			this.window_width = this.reportWindowWidth();
			this.nav_width = this.reportNavWidth();
			this.calculateNavWidth();

		},
		reportWindowWidth: function() {

			this.window_width = this.$window.width();

			return this.window_width;

		},
		reportNavWidth: function() {

			this.nav_width = this.$navigation.width();

			return this.nav_width;

		},
		calculateNavWidth: function() {

			var nav_width = solidMenus.reportNavWidth();

			if (nav_width > 996) {

				solidMenus.$full_width.outerWidth(nav_width);

			} else if (nav_width <= 996) {

				solidMenus.$full_width.outerWidth(nav_width);

				if (solidMenus.$nav_fixed.length === 1) {

					solidMenus.$full_width.outerWidth(nav_width);

				}

			}

		},
		triggerMenu: function(event) {

			var _this = $(this);

			_this.parent('li').toggleClass('is-click-active');
			_this.parent('li').siblings('li').removeClass('is-click-active');

			solidMenus.loadAnimation(_this);

		},
		triggerClickOutsideNav: function(event) {

			if ($(event.target).closest('#navigation').length === 0 ) {

				solidMenus.$trigger_click_li.removeClass('is-click-active');

			}

			solidMenus.$swivel_list.hide().removeAttr('class');

		},
		homeMenuHover: function() {

			var _this = $(this);
			var data_attribute = _this.attr('data-menu');

			_this.addClass('is-active').siblings('li').removeClass('is-active');
			_this.parents('.home-menu').siblings('.side-menu-wide').removeClass('is-active');
			_this.parents('.home-menu').siblings(".side-menu-wide" + "." + data_attribute).addClass('is-active');

		},
		firstMenuOnly: function(event) {

			var _this = $(this);
			var main_nav = '.main-nav';
			var menu_visible = 'menu-visible'
			var animation = 'animation-hingeTop';

			_this.toggleClass(menu_visible);

			if (solidMenus.$menu.hasClass(menu_visible)) {

				_this.siblings(main_nav).children('li').removeClass('is-click-active');
				
				$.each(_this.siblings(main_nav).children('li'), function(index, element) {

					$(element).removeAttr('style');

					setTimeout(function() {

						$(element).addClass(animation).fadeIn();

					}, (index * 150));

				});


			} else {

				solidMenus.removeClassRegEx(solidMenus.$main_nav_li, /^animation-/);

			}

			event.preventDefault();

		},
		fixedTop: function() {

			var nav_ft = $('#navigation.trigger-fixed-top');

			if (this.$window.scrollTop() > this.scroll_fix_value) {

				nav_ft.addClass('navigation-fixed-top');
				
			} else {

				nav_ft.removeClass('navigation-fixed-top');

			}

			solidMenus.calculateNavWidth();

		},
		openTab: function() {

			var _this = $(this);

			var input_id = _this.children('input').attr('id');
			var tab_content = _this.parents('.tab-menu').siblings('tr').find("td." + input_id);

			tab_content.siblings('td').hide(); 
			tab_content.show();

		},
		startSwivelClick: function() {

			var _this = $(this);
			var swivel_lists = _this.find('.swivel-lists > li');

			if (_this.hasClass('is-click-active')) {

				$.each(swivel_lists, function(index, element) {

					solidMenus.timer = setTimeout(function() {

						$(element).addClass(solidMenus.swivel_animation).fadeIn(500);

					}, (index * 100));

				});

			} else {

				solidMenus.removeSwivelClass();

			}
			
		},
		removeSwivelClass: function() {

			clearTimeout(this.timer);
			solidMenus.$swivel_list.removeClass(solidMenus.swivel_animation);

		},
		bookCategory: function() {

			var _this = $(this);
			var category_value = _this.val();
			var tab_content = _this.parents('.tab-menu').siblings('tr').find("td." + category_value);
			var tab_marker_radio = _this.siblings('.tab-marker').find('li').children('input');

			tab_content.siblings('td').hide();
			tab_content.show();

			$.each(tab_marker_radio, function(index, element) {

				if ($(element).hasClass(category_value)) {

					$(element).prop('checked', true);

				} else {

					$(element).prop('checked', false);

				}

			});

		},
		loadAnimation: function(target) {

			target.parent().find('div.animated').addClass(solidMenus.default_animation);

		},
		removeClassRegEx: function(target_element, target_pattern) { //target pattern must be a regular expression

			var target = target_element;
			var pattern = target_pattern;

			var classes;

			classes = target.attr('class').split(" "); //attribute classes to array

			for (x in classes) { //iterate each array and remove class based on the pattern match

				console.log(classes[x]);

				if (classes[x].match(pattern)) {

					target.removeClass(classes[x]);

				} 

			}

		},

		/* settings section */
		changeVersion: function() {

			var version_value = this.$version_changer.val();

			if (version_value === 'version-3') {

				window.location.href = '../mega-menu-v3/index.html';

			} else if (version_value === 'version-2') {

				window.location.href = '../mega-menu-v2/index.html';

			} else {

				window.location.href = '../mega-menu-bootstrap/index.html';

			}

		},
		changeMenu: function() {

			var menu_value = this.$menu_changer.val();

			if (menu_value  === "mega-menu-6") {

				this.$anim_and_trig.prop('disabled', true).css('background','gray');

			} else {

				this.$anim_and_trig.prop('disabled', false).css('background','white');

			}

			this.default_menu = menu_value + '.html';
			this.loadMenu();

			this.$mega_menu_changer.find('select').not(this.$menu_changer).prop('selectedIndex', 0);


		},
		changeResponsiveness: function() {

			var responsiveness_value = this.$responsiveness_changer.val();

			if (responsiveness_value == 'cover') {

				this.$main_nav.removeClass('uncover');

			} else {

				this.$main_nav.addClass('uncover'); // add class 'uncover' to class 'main-nav' to change responsiveness

			}

		},
		changeTrigger: function() {

			var trigger_value = this.$trigger_changer.val();

			this.$main_nav.removeClass('trigger-hover trigger-click');
			this.$main_nav.addClass(trigger_value);

		},
		changeTheme: function() {

			var _this = $(this);
			var css_path = "css/";
			var theme_id = _this.attr('id') + '.css'; //theme-01.css, them-02 + '.css'
		
			_this.css('transform','scale(1.2)').siblings('li').css('transform','scale(1)');
			$('link#themes').attr('href', css_path + theme_id);

		},
		changeAnimation: function() {

			this.default_animation = this.$animation_changer.val();
			solidMenus.removeClassRegEx(this.$div_animated,/^animation-/);

		},
		changeFt: function() {

			var trigger_value = this.$trigger_ft.val();

			this.$navigation.removeClass('trigger-fixed-top navigation-fixed-top');
			this.$navigation.addClass(trigger_value);

		}

	}

	solidMenus.init();

});
